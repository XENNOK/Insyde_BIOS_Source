This is IPMI Device Manager Config customization for OEM help files, here are two examples :

Example 1. How to add an new item

Example 2. Update an existing string token by specific way

You can use compare software to know how to modify

Follow the following steps to complete modification :

Example 1 : Add an new numeric option

a. Add OemIpmiDmConfigForm.h file to $(PROJECT_PKG)/Include folder and add new member to OEM field in OEM_IPMI_DM_CONFIG struct.

b. Add new member "Sample1Value" to OEM field in OEM_IPMI_DM_CONFIG struct.

c. Copy following files from InsydeIpmiPkg\Library\DxeOemIpmiDmConfigLib to $(PROJECT_PKG)/Library/DxeOemIpmiDmConfigLib
   1. DxeOemIpmiDmConfigLib.inf    : * Remove not modified file in [Sources] section
                                     * Add $(PROJECT_PKG)/Project.dec in [Packages] section for include OemIpmiDmConfigForm.h
   2. OemIpmiDmGetConfigDataSize.c : * Include OemIpmiDmConfigForm.h
                                     * Return OEM_IPMI_DM_CONFIG struct size for IPMI Device Manager Config Data size

d. Copy entire folder from InsydeIpmiPkg\Library\DxeIpmiDmConfigVfrLib to $(PROJECT_PKG)/Library/DxeIpmiDmConfigVfrLib
   Modify necessary file as below :
   1. DxeOemIpmiDmConfigLib.inf : * Add $(PROJECT_PKG)/Project.dec in [Packages] section for include OemIpmiDmConfigForm.h
   2. IpmiDmConfigVfr.vfr       : * Add new VFR option
   3. IpmiDmConfigStrings.uni   : * Add new token & string for VFR option prompt

e. Modify Project.dsc : * Set PcdIpmiConfigInDeviceManager to TRUE in [PcdsFixedAtBuild] section
                        * Add DxeOemIpmiDmConfigLib & DxeIpmiDmConfigVfrLib in [LibraryClasses.common.DXE_DRIVER] section

Example 2 : Update an existing MAC string token to xx-xx-xx-xx-xx-xx replace original xx:xx:xx:xx:xx:xx 

a. Copy entire folder from InsydeIpmiPkg\Library\DxeIpmiDmConfigVfrLib to $(PROJECT_PKG)/Library/DxeIpmiDmConfigVfrLib
   Modify necessary file as below :
   IpmiDmConfigVfrLib.c : * Implement function code to update string token and function name to gIpmiDmStringFunction table

b. Modify Project.dsc : * Set PcdIpmiConfigInDeviceManager to TRUE in [PcdsFixedAtBuild] section
                        * Add DxeIpmiDmConfigVfrLib in [LibraryClasses.common.DXE_DRIVER] section