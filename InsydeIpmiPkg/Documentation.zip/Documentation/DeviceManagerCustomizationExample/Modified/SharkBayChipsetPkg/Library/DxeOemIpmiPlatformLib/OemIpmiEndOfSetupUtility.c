/** @file
 OEM DXE IPMI Platform library implement code - End Of Setup Utility.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#include <Library/DxeOemIpmiPlatformLib.h>

#include <Library/UefiLib.h>

#include <Guid/H2OIpmiWatchdogTimer.h>


/**
 This funtion is called from SetupUtility.c after CallSetupUtilityBrowser.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiEndOfSetupUtility (
  VOID
  )
{
  EFI_STATUS                            Status;

  Status = EfiNamedEventSignal (&gH2OIpmiWatchdogTimerStartGuid);

  return Status;
}

