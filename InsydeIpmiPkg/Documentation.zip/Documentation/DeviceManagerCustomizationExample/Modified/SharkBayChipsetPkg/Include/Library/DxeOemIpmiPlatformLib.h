/** @file
 DXE OEM IPMI platform library header file.

 This file contains functions prototype that can be implemented by OEM to fit
 their requirements.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#ifndef _DXE_OEM_IPMI_PLATFORM_LIB_H_
#define _DXE_OEM_IPMI_PLATFORM_LIB_H_


#include <PiDxe.h>


/**
 This funtion is called from BdsPlatform.c PlatformBdsPolicyBehavior.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiBootOption (
  VOID
  );


/**
 This funtion is called from BdsPlatform.c before BdsLibConnectLegacyRoms.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiStartOfShadowRom (
  VOID
  );


/**
 This funtion is called from BdsPlatform.c after BdsLibConnectLegacyRoms.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiEndOfShadowRom (
  VOID
  );


/**
 This funtion is called from FrontPage.c before CallFrontPage.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiStartOfFrontPage (
  VOID
  );


/**
 This funtion is called from FrontPage.c after CallFrontPage.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiEndOfFrontPage (
  VOID
  );


/**
 This funtion is called from SetupUtility.c before CallSetupUtilityBrowser.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiStartOfSetupUtility (
  VOID
  );


/**
 This funtion is called from SetupUtility.c after CallSetupUtilityBrowser.

 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return Status                         Platform implement this function and return EfiNamedEventSignal Status.
*/
EFI_STATUS
OemIpmiEndOfSetupUtility (
  VOID
  );


#endif

