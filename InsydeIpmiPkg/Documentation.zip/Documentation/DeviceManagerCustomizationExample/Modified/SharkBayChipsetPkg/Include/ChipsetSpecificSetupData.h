/** @file
  Chipset Setup Configuration Data

;******************************************************************************
;* Copyright (c) 2012 - 2013, Insyde Software Corp. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************
*/

#ifdef _IMPORT_CHIPSET_SPECIFIC_SETUP_

//==========================================================================================================
//==========================================================================================================
//----------------------------------------------------------------------------------------------------------
// Start area for Platform. The following area is used by Chipset team to modify.
// The total size of variable in this part are fixed (500bytes). That means if you need to add or remove
// variables, please modify the PlatformRSV buffer size as well.
//----------------------------------------------------------------------------------------------------------
//Platform_Start
//Offset(700);

  //
  // SATA Configuration
  // Offset(700:30)
  //
  UINT8         AhciOptionRomSupport;                 //Offset 700
  UINT8         AggressLinkPower;
  UINT8         RaidAlternateId;
  UINT8         HdcP0HotPlug;
  UINT8         HdcP1HotPlug;
  UINT8         HdcP2HotPlug;
  UINT8         HdcP3HotPlug;
  UINT8         HdcP4HotPlug;
  UINT8         HdcP5HotPlug;
  UINT8         HdcP0SpinUp;
  UINT8         HdcP1SpinUp;                          //Offset 710
  UINT8         HdcP2SpinUp;
  UINT8         HdcP3SpinUp;
  UINT8         HdcP4SpinUp;
  UINT8         HdcP5SpinUp;
  UINT8         HddUnlock;
  UINT8         LedLocate;
  UINT8         Raid0;
  UINT8         Raid1;
  UINT8         Raid10;
  UINT8         Raid5;                                //Offset 720
  UINT8         Irrt;
  UINT8         OromUiBanner;
  UINT8         IrrtOnly;
  UINT8         SataP0DeviceType;
  UINT8         SataP1DeviceType;
  UINT8         SataP2DeviceType;
  UINT8         SataP3DeviceType;
  UINT8         SataP4DeviceType;
  UINT8         SataP5DeviceType;

  //
  // RapidStart
  // Offset(730:6)
  //
  UINT8         EnableRapidStart;                     //Offset 730
  UINT8         EntryOnS3RtcWake;
  UINT16        S3WakeTimerMin;
  UINT8         EntryOnS3CritBattWake;
  UINT8         CritticalBatWakeThres;

  //
  // iSCT
  // Offset(736:4)
  //
  UINT8         ISCTEnable;
  UINT8         ISCTNotify;
  UINT8         ISCTWLanPower;
  UINT8         ISCTWWLanPower;

  //
  // Overclocking Configuration
  // Offset(740:26)
  //
  UINT8         Overclocking;                         //Offset 740
  UINT8         OcReserved01;
  UINT8         FlexRatioOverride;
  UINT8         FlexRatio;
  UINT16        HostClockFreq;
  UINT8         MemoryTcwl;
  UINT8         MemoryTcl;
  UINT8         MemoryTrcd;
  UINT8         MemoryTrp;
  UINT8         MemoryTras;                           //Offset 750
  UINT8         MemoryTwr;
  UINT16        MemoryTrfc;
  UINT8         MemoryTrrd;
  UINT8         MemoryTwtr;
  UINT8         MemoryTrtp;
  UINT8         MemoryTrc;
  UINT8         MemoryTfaw;
  UINT8         MemoryVoltage;
  UINT8         XmpProfileSetting;                    //Offset 760
  UINT8         MemoryTrpab;
  UINT16        MemoryTrefi;
  UINT8         OcReserved02;
  UINT8         GtOverclockFreq;

  //
  // ME / AT
  // Offset(766:4)
  //
  UINT8         AtConfig;
  UINT8         AtState;
  UINT8         AtEnterSuspendState;
  UINT8         IFRUpdate;
  
  //
  // ICC
  // Offset(770:14)
  //
  UINT8         IccCapabilities;                      //Offset 770
  UINT8         IccWatchDog;
  UINT8         IccUnusedPci;
  UINT8         IccLockRegisters;
  UINT8         IccProfile;
  UINT8         IccOperable;
  UINT8         IccClockPage;
  UINT16        IccNewDivisor;
  UINT8         IccNewSccMode;
  UINT8         IccNewSccValue;                       //Offset 780
  UINT8         IccApply;
  UINT8         IccBackupProfile;
  UINT8         IccSupportedProfilesNumber;

  //
  // GPIO
  // Offset(784:1)
  //
  UINT8         GpioLockdown;

  //
  // DPTF / cTDP
  // Offset(785:38)
  //
  UINT8         EnableDptf;
  UINT8         DptfProcessorThermalDevice;
  UINT8         DptfPchThermalDevice;
  UINT8         LPM;
  UINT8         CurrentLowPowerMode;
  UINT8         cTDP;                                 //Offset 790
  UINT8         ConfigTDPCapability;
  UINT8         ConfigTDPLevel;
  UINT8         ActivePageThresholdEnable;
  UINT32        ActivePageThresholdSize;
  UINT8         ConfigTDPLock;
  UINT8         ConfigTdpCustom;
  UINT8         CustomTdpCount;                       //Offset 800
  UINT8         CustomBootModeIndex;
  UINT16        CustomPowerLimit10;
  UINT16        CustomPowerLimit20;
  UINT8         CustomPowerLimit1Time0;
  UINT8         CustomTurboActivationRatio0;
  UINT8         CustomConfigTdpControl0;
  UINT16        CustomPowerLimit11;                   //Offset 809 - 810
  UINT16        CustomPowerLimit21;
  UINT8         CustomPowerLimit1Time1;
  UINT8         CustomTurboActivationRatio1;
  UINT8         CustomConfigTdpControl1;
  UINT16        CustomPowerLimit12;
  UINT16        CustomPowerLimit22;
  UINT8         CustomPowerLimit1Time2;               //Offset 820
  UINT8         CustomTurboActivationRatio2;
  UINT8         CustomConfigTdpControl2;

  //
  // Misc
  // Offset(823:1)
  // 
  UINT8         RtcLock;
 
  // 
  // CPPC 
  // 
  UINT8         EnableCppc;
  UINT8         EnableCppcPlatformSCI;
  UINT16        MaxTOLUD;
  UINT8         S5LongRunTest;
  UINT8         BistOnReset;
  UINT8         Pfat;                                 //Offset 830
  UINT8         HardwarePrefetcher;
  UINT8         BootInLfm;
  UINT8         EnergyPolicy;
  UINT8         DdrPowerLimitLock;
  UINT8         DdrLongTermPowerLimitOverride;
  UINT8         DdrShortTermPowerLimitOverride;
  UINT8         DdrLongTermPowerLimit;
  UINT8         DdrLongTermTimeWindow;
  UINT8         DdrShortTermPowerLimit;
  UINT8         ActiveThermalTripPointMCH;            //Offset 840
  UINT8         PassiveThermalTripPointMCH;
  UINT8         CriticalThermalTripPointSa;
  UINT8         HotThermalTripPointSa;
  UINT32        PPCCStepSize;
  UINT8         LPOEnable;
  UINT8         LPOStartPState;
  UINT8         LPOStepSize;                          //Offset 850
  UINT8         LPOPowerControlSetting;
  UINT8         LPOPerformanceControlSetting;
  UINT8         ActiveThermalTripPointPCH;
  UINT8         PassiveThermalTripPointPCH;
  UINT8         CriticalThermalTripPointPch;
  UINT8         HotThermalTripPointPch;
  UINT8         EnableMemoryDevice;
  UINT8         ActiveThermalTripPointTMEM;
  UINT8         PassiveThermalTripPointTMEM;
  UINT8         CriticalThermalTripPointTMEM;         //Offset 860
  UINT8         HotThermalTripPointTMEM;
  UINT8         EnableFan1Device;
  UINT8         EnableFan2Device;
  UINT8         EnableAmbientDevice;
  UINT8         ActiveThermalTripPointAmbient;
  UINT8         PassiveThermalTripPointAmbient;
  UINT8         CriticalThermalTripPointAmbient;
  UINT8         HotThermalTripPointAmbient;
  UINT8         EnableSkinDevice;
  UINT8         ActiveThermalTripPointSkin;           //Offset 870
  UINT8         PassiveThermalTripPointSkin;
  UINT8         CriticalThermalTripPointSkin;
  UINT8         HotThermalTripPointSkin;
  UINT8         EnableExhaustFanDevice;
  UINT8         ActiveThermalTripPointExhaustFan;
  UINT8         PassiveThermalTripPointExhaustFan;
  UINT8         CriticalThermalTripPointExhaustFan;
  UINT8         HotThermalTripPointExhaustFan;
  UINT8         EnableVRDevice;
  UINT8         ActiveThermalTripPointVR;             //Offset 880
  UINT8         PassiveThermalTripPointVR;
  UINT8         CriticalThermalTripPointVR;
  UINT8         HotThermalTripPointVR;
  UINT8         EnableActivePolicy;
  UINT8         EnablePassivePolicy;
  UINT8         EnableCriticalPolicy;
  UINT8         EnableCoolingModePolicy;
  UINT8         TrtRevision;
  UINT16        SataP0TimeOut;                        //Offset 889 - 890
  UINT8         FullGenericParticipant;
  UINT8         EnableLowPowerS0Cap;
  UINT8         EnableSerialIoDma;
  UINT8         EnableSerialIoI2c0;
  UINT8         EnableSerialIoI2c1;
  UINT8         EnableSerialIoSpi0;
  UINT8         EnableSerialIoSpi1;
  UINT8         EnableSerialIoUart0;
  UINT8         EnableSerialIoUart1;
  UINT8         EnableSerialIoSdio;                   //Offset 900
  UINT8         EnableSerialIoAudioDsp;
  UINT8         SerialIoMode;
  UINT8         RuntimeDevice3;
  UINT8         DisPlayMode;
  UINT8         PEGWorkAround;
  UINT8         EnableC8;
  UINT8         EnableC9;
  UINT8         EnableC10;
  UINT8         CstateLatencyControl3TimeUnit;
  UINT8         CstateLatencyControl4TimeUnit;        //Offset 910
  UINT8         CstateLatencyControl5TimeUnit;
  UINT16        CstateLatencyControl3Irtl;
  UINT16        CstateLatencyControl4Irtl;
  UINT16        CstateLatencyControl5Irtl;
  UINT8         EnableACPIDebug;
  UINT32        ACPIDebugAddr;
  UINT8         TbtWorkaround;
  UINT8         TbtSxWakeTimer;
  UINT16        ReserveMemoryPerSlot;
  UINT16        ReservePMemoryPerSlot;
  UINT8         ReserveIOPerSlot;
  UINT8         IsctTimerChoice;                      //Offset 930
  UINT8         NfcSelection;
  UINT8         AudioDspD3PowerGating;
  UINT8         AudioDspBluetoothSupport;
  UINT8         AudioDspAcpiMode;
  UINT8         AudioCodecSelect;
  UINT8         HybridHardDisk;
  UINT8         DisplaySaveRestore;
  UINT8         DisplayType;
  UINT8         FTpmSwitch;
  UINT8         Rtd3UsbSpeed1;                        //Offset 940
  UINT8         Rtd3UsbSpeed2;
  UINT8         PepGfx;
  UINT8         PepSata;
  UINT8         MemThermalManage;
  UINT8         PeciInjectedTemp;
  UINT8         ExttsViaTsOnBoard;
  UINT8         ExttsViaTsOnDimm;
  UINT8         VirtualTempSensor;
  
  UINT8         LockThermalManageRegs;
  UINT8         ExternThermalStatus;                  //Offset 950
  
  UINT8         ClosedLoopThermalManage;
  UINT8         OpenLoopThermalManage;
  
  UINT8         WarmThresholdCh0Dimm0;
  UINT8         WarmThresholdCh0Dimm1;
  UINT8         HotThresholdCh0Dimm0;
  UINT8         HotThresholdCh0Dimm1;
  
  UINT8         WarmThresholdCh1Dimm0;
  UINT8         WarmThresholdCh1Dimm1;
  UINT8         HotThresholdCh1Dimm0;
  UINT8         HotThresholdCh1Dimm1;                 //Offset 960
  
  UINT8         WarmBudgetCh0Dimm0;
  UINT8         WarmBudgetCh0Dimm1;
  UINT8         HotBudgetCh0Dimm0;
  UINT8         HotBudgetCh0Dimm1;
  
  UINT8         WarmBudgetCh1Dimm0;
  UINT8         WarmBudgetCh1Dimm1;
  UINT8         HotBudgetCh1Dimm0;
  UINT8         HotBudgetCh1Dimm1;

  UINT8         RaplPLLock;
  UINT8         RaplPL1Enable;                        //Offset 970
  UINT16        RaplPL1Power;
  UINT8         RaplPL1WindowX;
  UINT8         RaplPL1WindowY;
                       
  UINT8         RaplPL2Enable;
  UINT16        RaplPL2Power;
  UINT8         RaplPL2WindowX;
  UINT8         RaplPL2WindowY;
  UINT8         EnableWifiDevice;                     //Offset 980
  UINT8         ActiveThermalTripPointWifi;
  UINT8         PassiveThermalTripPointWifi;
  UINT8         CriticalThermalTripPointWifi;
  UINT8         HotThermalTripPointWifi;
  UINT8         EnablePowerDevice;
  UINT8         EnablePowerPolicy;
  UINT8         EnableDisplayParticipant;
  //
  // Overclocking Configuration
  //
  UINT8         OcCapIaCore;
  UINT8         OcCapGt;
  UINT8         OcCapClr;                             //Offset 990
  UINT8         OcCapUncore;
  UINT8         OcCapIoa;
  UINT8         OcCapIod;
  UINT16        CoreMaxOcRatio;
  UINT8         CoreVoltageMode;
  UINT16        CoreExtraTurboVoltage;
  UINT16        CoreVoltageOverride;                  //Offset 999 - 1000
  UINT16        CoreVoltageOffset;
  UINT8         CoreVoltageOffsetPrefix;
  UINT16        ClrMaxOcRatio;
  UINT8         ClrVoltageMode;
  UINT16        ClrExtraTurboVoltage;
  UINT16        ClrVoltageOverride;                   //Offset 1009 - 1010
  UINT16        ClrVoltageOffset;
  UINT8         ClrVoltageOffsetPrefix;
  UINT8         SvidSupport;
  UINT16        SvidVoltageOverride;
  UINT8         FivrFaults;
  UINT8         FivrEfficiencyManagement;
  UINT8         GtVoltageMode;
  UINT16        GtExtraTurboVoltage;                  //Offset 1019 - 1020
  UINT16        GtVoltageOverride;
  UINT16        GtVoltageOffset;
  UINT8         GtVoltageOffsetPrefix;
  UINT16        UncoreVoltageOffset;
  UINT8         UncoreVoltageOffsetPrefix;
  UINT16        IoaVoltageOffset;                     //Offset 1030 - 1031
  UINT8         IoaVoltageOffsetPrefix;
  UINT16        IodVoltageOffset;
  UINT8         IodVoltageOffsetPrefix;
  UINT8         MemoryRefClk;
  UINT8         MemoryRatio;
  UINT8         SaAudioEnable;
  UINT8         SataP0DeviceSleep;
  UINT8         SataP1DeviceSleep;                    //Offset 1040
  UINT8         SataP2DeviceSleep;
  UINT8         SataP3DeviceSleep;
  UINT8         SataP4DeviceSleep;
  UINT8         SataP5DeviceSleep;
  UINT8         SataP0EnableDito;
  UINT8         SataP1EnableDito;
  UINT8         SataP2EnableDito;
  UINT8         SataP3EnableDito;
  UINT8         SataP4EnableDito;
  UINT8         SataP5EnableDito;                     //Offset 1050
  UINT16        SataP0DitoVal;
  UINT16        SataP1DitoVal;
  UINT16        SataP2DitoVal;
  UINT16        SataP3DitoVal;
  UINT16        SataP4DitoVal;                        //Offset 1059 - 1060
  UINT16        SataP5DitoVal;
  UINT8         SataP0DmVal;
  UINT8         SataP1DmVal;
  UINT8         SataP2DmVal;
  UINT8         SataP3DmVal;
  UINT8         SataP4DmVal;
  UINT8         SataP5DmVal;

  //
  // I2c
  // Offset (1075:20)
  //
  UINT8         I2c0IntelSensorHub;
  UINT8         I2c0WITTDevice;                       //Offset 1070
  UINT16        I2c1AtmelTouchPanel;
  UINT16        I2c1ElantechTouchPanel;
  UINT16        I2c1ElantechTouchPad;
  UINT16        I2c1SynapticsTouchPad;
  UINT16        I2c1WITTDevice;                       //Offset 1079 - 1080
  UINT16        I2c1NTrigDigitizer;
  UINT16        I2c1EETITouchPanel;
  UINT16        I2c1AlpsTouchPad;
  UINT16        I2c1CypressTouchPad;

  UINT8         ECLowPowerS0IdleEnable;
  
  //
  // RTD3
  // Offset (1096:12)
  //
  UINT16        Rtd3AudioDeviceDelay;                 //Offset 1090 - 1091
  UINT16        Rtd3AdspDeviceDelay;
  UINT16        I2c0DeviceDelayTiming;
  UINT16        I2c1DeviceDelayTiming;
  UINT8         PStateCapping;
  UINT8         Rtd3CongigSetting;

  //
  // Intel Ultrabook Event Support
  //
  UINT8         IuerDockEnable;                       //Offset 1100
  UINT8         IuerButtonEnable;
  UINT8         NativePCIESupport;
  UINT8         AudioDisableBitmap;
  UINT8         Tpm2Flag;
//[-start-130123-IB04770265-add]//
  UINT8         TbtWakeFromDevice;
//[-end-130123-IB04770265-add]//
//[-start-130307-IB03780481-add]//
  UINT8         TbtRsvdBus;
  UINT16        TbtRsvdIo;
  UINT16        TbtRsvdMem;                           //Offset 1109 - 1110
  UINT16        TbtRsvdPmem;
  UINT8         TbtRsvdMemAlign;
  UINT8         TbtRsvdPmemAlign;                     //Offset 1114
//[-end-130307-IB03780481-add]//
  //
  // BMC/IPMI
  // Offset(1115:65)
  //
  UINT8         IpmiBootOption;
  UINT8         IpmiEnable;
  UINT8         IpmiSetBiosVersion;
  UINT8         IpmiSdrListEnable;
  UINT8         IpmiSpmiEnable;
  UINT8         BmcWdtEnable;
  UINT8         BmcWdtTimeout;
  UINT8         BmcWdtAction;
  UINT8         BmcWarmupTime;
  UINT8         BmcLanPortConfig;
  UINT8         BmcLanChannel;
  UINT8         BmcIPv4Source;
  UINT8         BmcIPv4IpAddress[4];
  UINT8         BmcIPv4SubnetMask[4];
  UINT8         BmcIPv4GatewayAddress[4];
  UINT8         BmcFrontPanelPwrBtn;
  UINT8         BmcFrontPanelRstBtn;
  UINT8         BmcFrontPanelNmiBtn;
  UINT8         BmcStatus;
  UINT8         BmcIPv6Mode;
  UINT8         BmcIPv6AutoConfig;
  UINT8         BmcIPv6PrefixLength;
  UINT8         BmcIPv6IpAddress[16];
  UINT8         BmcIPv6GatewayAddress[16];
  UINT8         BmcPowerCycleTimeEnable;
  UINT8         BmcPowerCycleTime;                    //offset 1179
  UINT8         PlatformRSV[20];                      //Offset 1180 - 1199
//Platform_End
//----------------------------------------------------------------------------------------------------------
// End of area for Chipset team use.
//----------------------------------------------------------------------------------------------------------

#endif