/** @file
 Formset Guids, form ID and VarStore Data structure for IPMI Device Manager Config.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#ifndef _OEM_IPMI_DM_CONFIG_FORM_
#define _OEM_IPMI_DM_CONFIG_FORM_


#include <IpmiDmConfigForm.h>


#pragma pack(1)

//
// IPMI General Configuration Structure.
//
typedef struct {
  //
  // Import IPMI General configuration definition from IpmiGeneralConfigData.h
  //
  #define _IMPORT_IPMI_GENERAL_CONFIG_
  #include <IpmiGeneralConfigData.h>
  #undef _IMPORT_IPMI_GENERAL_CONFIG_

  //
  // Reserved for OEM can add data to fit their requirements.
  //
  UINT8       Sample1Value;
} OEM_IPMI_DM_CONFIG;

#pragma pack()


#endif
