/** @file
 OEM DXE IPMI Package library implement code - Update Policy.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#include <Library/DxeOemIpmiPackageLib.h>


/**
 This package function can update platform policy based on setup settings.
 Platform can implement this function to set correct variable.

 @retval EFI_SUCCESS                    Platform implement this function.
 @retval EFI_UNSUPPORTED                Platform does not implement this function.
*/
EFI_STATUS
OemIpmiUpdatePolicy (
  VOID
  )
{
  //
  // Platform can update policy if necessary
  //

  return EFI_SUCCESS;

}

