/** @file
 OEM DXE IPMI Package library implement code - Enter Setup.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#include <Library/DxeOemIpmiPackageLib.h>

#include <Library/UefiBootServicesTableLib.h>

#include <Protocol/EfiSetupUtility.h>


/**
 This package function can enter setup utility as IPMI boot option request.
 Platform can implement this function since entering setup utility is a platform dependent function.

 @retval EFI_SUCCESS                    Entering setup utility success.
 @retval EFI_UNSUPPORTED                Platform does not implement this function.
 @return EFI_ERROR (Status)             Locate gEfiSetupUtilityProtocolGuid Protocol error.
*/
EFI_STATUS
OemIpmiEnterSetup (
  VOID
  )
{
  EFI_SETUP_UTILITY_PROTOCOL            *SetupUtility;
  EFI_STATUS                            Status;

  Status = gBS->LocateProtocol (
                  &gEfiSetupUtilityProtocolGuid,
                  NULL,
                  &SetupUtility
                  );

  if (!EFI_ERROR (Status)) {
    SetupUtility->StartEntry (SetupUtility);
  }

  return Status;

}

