/** @file
 OEM PEI IPMI Package library implement code - Update Policy.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#include <Library/PeiOemIpmiPackageLib.h>
#include <Library/PeiServicesLib.h>
#include <Library/PcdLib.h>

#include <Ppi/ReadOnlyVariable2.h>

#include <SetupConfig.h>


/**
 Update IPMI policy according to the "Setup" variable SYSTEM_CONFIGURATION or
 IPMI Device Config Variable when PcdIpmiConfigInDeviceManager is TRUE.

 @param[in]         PeiServices         A pointer to EFI_PEI_SERVICES struct pointer.

 @retval EFI_SUCCESS                    Update Policy success.
 @retval EFI_NOT_FOUND                  Locate gEfiPeiReadOnlyVariable2PpiGuid or GetVariable error.
 @retval EFI_UNSUPPORTED                OEM does not implement this function.
*/
EFI_STATUS
OemIpmiUpdatePolicy (
  IN CONST EFI_PEI_SERVICES             **PeiServices
  )
{
  EFI_STATUS                            Status;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI       *VariablePpi;
  UINTN                                 Size;
  SYSTEM_CONFIGURATION                  SetupConfig;

  Status = (*PeiServices)->LocatePpi (PeiServices, &gEfiPeiReadOnlyVariable2PpiGuid, 0, NULL, &VariablePpi);
  if (EFI_ERROR (Status)) {
    return EFI_NOT_FOUND;
  }

  if (FeaturePcdGet (PcdIpmiConfigInDeviceManager) == FALSE) {

    Size = sizeof (SYSTEM_CONFIGURATION);
    Status = VariablePpi->GetVariable (
                            VariablePpi,
                            SETUP_VARIABLE_NAME,
                            &gSystemConfigurationGuid,
                            NULL,
                            &Size,
                            &SetupConfig
                            );
    if (EFI_ERROR (Status)) {
      return EFI_NOT_FOUND;
    }

    if (SetupConfig.SetupVariableInvalid == 0) {
      PcdSet8 (PcdIpmiEnable, SetupConfig.IpmiEnable);
      PcdSet8 (PcdBmcWarmupTime, SetupConfig.BmcWarmupTime);
      PcdSet8 (PcdBmcWdtEnable, SetupConfig.BmcWdtEnable);
      PcdSet8 (PcdBmcWdtAction, SetupConfig.BmcWdtAction);
      PcdSet8 (PcdBmcWdtTimeout, SetupConfig.BmcWdtTimeout);
      PcdSet8 (PcdIpmiSpmiEnable, SetupConfig.IpmiSpmiEnable);
      PcdSet8 (PcdIpmiSetBiosVersion, SetupConfig.IpmiSetBiosVersion);
      PcdSet8 (PcdIpmiBootOption, SetupConfig.IpmiBootOption);
    }

  } else {

    //
    // Reserved for OEM to update policy by different IPMI Device Manager Config Variable Name GUID.
    //

    return EFI_UNSUPPORTED;

  }

  return EFI_SUCCESS;

}

