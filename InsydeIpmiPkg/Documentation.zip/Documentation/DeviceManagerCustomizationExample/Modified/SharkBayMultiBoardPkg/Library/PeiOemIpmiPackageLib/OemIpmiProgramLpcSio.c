/** @file
 OEM PEI IPMI Package library implement code - Program LPC Sio.

;******************************************************************************
;* Copyright (c) 2013, Insyde Software Corporation. All Rights Reserved.
;*
;* You may not reproduce, distribute, publish, display, perform, modify, adapt,
;* transmit, broadcast, present, recite, release, license or otherwise exploit
;* any part of this publication in any form, by any means, without the prior
;* written permission of Insyde Software Corporation.
;*
;******************************************************************************

*/


#include <Library/PeiOemIpmiPackageLib.h>
#include <Library/IoLib.h>
#include <Library/PcdLib.h>
#include <Base.h>
#include <PchRegs.h>
#include <PchAccess.h>


#define SIO_CONFIG_PORT1          0x2E
#define SIO_CONFIG_PORT2          0x4E
#define REG_LOGICAL_DEVICE        0x07
#define ACTIVATE                  0x30
#define BASE_ADDRESS_HIGH0        0x60
#define BASE_ADDRESS_LOW0         0x61
#define BASE_ADDRESS_HIGH1        0x62
#define BASE_ADDRESS_LOW1         0x63

//
// ====== SIO PILOT III ======
//
#define PILOT3_SIO_INDEX_PORT     SIO_CONFIG_PORT2
#define PILOT3_SIO_DATA_PORT      (PILOT3_SIO_INDEX_PORT+1)

#define PILOT3_SIO_UNLOCK         0x5A
#define PILOT3_SIO_LOCK           0xA5

#define PILOT3_SIO_KCS1           0x06
#define PILOT3_SIO_KCS2           0x07
#define PILOT3_SIO_KCS3           0x08
#define PILOT3_SIO_KCS4           0x09
#define PILOT3_SIO_KCS5           0x0A


#pragma pack(1)

typedef struct {
  UINT8 Register;
  UINT8 Value;
} SIO_CONFIG_TABLE;

#pragma pack()

UINT8  IoDecodeRegisterTable[] = {
  R_PCH_LPC_GEN1_DEC,
  R_PCH_LPC_GEN2_DEC,
  R_PCH_LPC_GEN3_DEC,
  R_PCH_LPC_GEN4_DEC
  };


/**
 Programming PCH LPC Generic I/O Decode Range Register to Super I/O for BMC use.
 And config SuperIo for BMC if necessary.

 @param[in]         PeiServices         A pointer to EFI_PEI_SERVICES struct pointer.
 @param[in]         IpmiSmmBaseAddress  Value from FixedPcdGet16 (PcdIpmiSmmBaseAddress).
 @param[in]         IpmiSmmRegOffset    Value from FixedPcdGet16 (PcdIpmiSmmRegOffset).
 @param[in]         IpmiPostBaseAddress Value from FixedPcdGet16 (PcdIpmiPostBaseAddress).
 @param[in]         IpmiPostRegOffset   Value from FixedPcdGet16 (PcdIpmiPostRegOffset).
 @param[in]         IpmiOsBaseAddress   Value from FixedPcdGet16 (PcdIpmiOsBaseAddress).
 @param[in]         IpmiOsRegOffset     Value from FixedPcdGet16 (PcdIpmiOsRegOffset).
 @param[in]         IpmiLpcDecode       Value from FixedPcdGetBool (PcdIpmiLpcDecode).
 @param[in]         IpmiSioConfig       Value from FixedPcdGetBool (PcdIpmiSioConfig).

 @retval EFI_SUCCESS                    Programming success.
 @retval EFI_OUT_OF_RESOURCES           No unused Generic Decode Range Register can decode.
 @retval EFI_UNSUPPORTED                Platform does not implement this function.
*/
EFI_STATUS
OemIpmiProgramLpcSio (
  IN CONST EFI_PEI_SERVICES             **PeiServices,
  IN       UINT16                       IpmiSmmBaseAddress,
  IN       UINT16                       IpmiSmmRegOffset,
  IN       UINT16                       IpmiPostBaseAddress,
  IN       UINT16                       IpmiPostRegOffset,
  IN       UINT16                       IpmiOsBaseAddress,
  IN       UINT16                       IpmiOsRegOffset,
  IN       BOOLEAN                      IpmiLpcDecode,
  IN       BOOLEAN                      IpmiSioConfig
  )
{
  UINT8                                 Index;
  BOOLEAN                               DecodeSuccess;
  UINT8                                 ConfigPort;
  UINT8                                 IndexPort;
  UINT8                                 DataPort;
  UINT16                                DecodeBaseAddr;
  UINT16                                DecodeAddrEnd;
  SIO_CONFIG_TABLE                      SioConfigTable[] ={
                                          //
                                          // Active Logical Devices 9 (KCS4)
                                          //
                                          {
                                            REG_LOGICAL_DEVICE,
                                            PILOT3_SIO_KCS4
                                          },
                                          {
                                            BASE_ADDRESS_HIGH0,
                                            0
                                          },
                                          {
                                            BASE_ADDRESS_LOW0,
                                            0
                                          },
                                          {
                                            BASE_ADDRESS_HIGH1,
                                            0
                                          },
                                          {
                                            BASE_ADDRESS_LOW1,
                                            0
                                          },
                                          {
                                            ACTIVATE,
                                            0x01
                                          },
                                          {
                                            0xff,
                                            0xff
                                          }
                                        };

  SioConfigTable[1].Value = (UINT8)(IpmiPostBaseAddress >> 8);
  SioConfigTable[2].Value = (UINT8)(IpmiPostBaseAddress & 0xFF);
  SioConfigTable[3].Value = (UINT8)((IpmiPostBaseAddress + IpmiPostRegOffset) >> 8);
  SioConfigTable[4].Value = (UINT8)((IpmiPostBaseAddress + IpmiPostRegOffset) & 0xFF);

  if (IpmiLpcDecode) {

    //
    // Check if the Address Range in the IoDecodeTable is already programmed.
    //
    Index = 0;
    DecodeSuccess = FALSE;
    while (Index < (sizeof (IoDecodeRegisterTable) / sizeof (UINT8))) {
      if (PchLpcPciCfg16 (IoDecodeRegisterTable[Index]) != 0) {
        DecodeBaseAddr = (PchLpcPciCfg16 (IoDecodeRegisterTable[Index]) & (UINT16)(~BIT0));
        DecodeAddrEnd = DecodeBaseAddr + (UINT16)((PchLpcPciCfg32 (IoDecodeRegisterTable[Index]) >> 16) + 0x03);
        if ((DecodeBaseAddr <= (IpmiPostBaseAddress & 0xFFF0)) &&
            ((IpmiPostBaseAddress | 0x000F) <= DecodeAddrEnd)) {
          DecodeSuccess = TRUE;
          break;
        }
      }
      Index++;
    }

    //
    // Program PCH LPC I/F Generic decode address
    //
    if (DecodeSuccess == FALSE) {
      Index = 0;
      while (Index < (sizeof (IoDecodeRegisterTable) / sizeof (UINT8))) {
        if (PchLpcPciCfg16 (IoDecodeRegisterTable[Index]) == 0) {
          MmioWrite32 (
            MmPciAddress (0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_LPC, 0, IoDecodeRegisterTable[Index++]),
            (UINT32)((UINT32)(((~0xFFF0) & 0xFC) << 16) + (UINT32)((IpmiPostBaseAddress & 0xFFF0) + 1))
            );
          DecodeSuccess = TRUE;
          break;
        }
        Index++;
      }
    }

    if (DecodeSuccess == FALSE) {
      return EFI_OUT_OF_RESOURCES;
    }

  }


  if (IpmiSioConfig) {

    ConfigPort = SIO_CONFIG_PORT2;
    IndexPort  = PILOT3_SIO_INDEX_PORT;
    DataPort   = PILOT3_SIO_DATA_PORT;

    //
    // Program and Enable SIO Base Addresses 0x2E and 0x4E
    //
    PchLpcPciCfg16Or (R_PCH_LPC_ENABLES, B_PCH_LPC_ENABLES_CNF1_EN | B_PCH_LPC_ENABLES_CNF2_EN);

    //
    // Enter Config Mode
    //
    IoWrite8 (ConfigPort, PILOT3_SIO_UNLOCK);
    IoWrite8 (ConfigPort, 0x00); // 0x00 be end

    //
    // Configure SIO
    //
    for (Index = 0; Index < sizeof (SioConfigTable) / sizeof (SIO_CONFIG_TABLE); Index++) {
      IoWrite8 (IndexPort, SioConfigTable[Index].Register);
      IoWrite8 (DataPort, SioConfigTable[Index].Value);
    }

    //
    // Exit Config Mode
    //
    IoWrite8 (ConfigPort, PILOT3_SIO_LOCK);
    IoWrite8 (ConfigPort, 0x00); // 0x00 be end

  }

  return EFI_SUCCESS;

}

