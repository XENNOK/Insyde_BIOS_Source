This sample is base on Intel_SharkBay_FHC_Rev5.0 - Trunk rev. 2929

Follow the following steps to add APEI feature:
1. Add InsydeApeiPkg to WORKSPACE.
2. Use Beyond Compare to see where need to modify and add file.

SharkBay_FHC_Rev5.0_Origianl is original folder.

SharkBay_FHC_Rev5.0_Modify is modify sample.